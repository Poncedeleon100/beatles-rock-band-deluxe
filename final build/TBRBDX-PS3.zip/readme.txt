Install the .pkg file like normal.
Copy the contents of the "Disc Patch (Required)" folder on top of where your vanilla copy of TBRB is installed.

It is normal for TBRB to take longer to start up on PS3/RPCS3.